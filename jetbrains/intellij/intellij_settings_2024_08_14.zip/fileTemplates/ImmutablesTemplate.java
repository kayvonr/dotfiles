#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.immutables.value.Value;

@Value.Immutable
@JsonSerialize(as = Immutable${NAME}.class)
@JsonDeserialize(as = Immutable${NAME}.class)
public interface ${NAME} {
    
    class Builder extends Immutable${NAME}.Builder {}

    static Builder builder() {
        return new Builder();
    }

}