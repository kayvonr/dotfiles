@org.junit.jupiter.api.Test
void ${NAME}() {
  ${BODY}
}
